SWATAccessoires = {
  
}
